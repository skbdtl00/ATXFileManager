import { FileManager } from "@/components/file-manager"

export default function Home() {
  return (
    <main className="min-h-screen">
      <FileManager />
    </main>
  )
}
